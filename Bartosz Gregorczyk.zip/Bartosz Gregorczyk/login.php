
<?php
session_start();

$login = $_COOKIE['login'] ?? '';
$blad = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
$user = $_POST['login'];
$haslo = $_POST['haslo'];
if ($user == 'admin' && $haslo == '1234') {
 $_SESSION['user'] = $user;
if (isset($_POST['zapamietaj'])) {
setcookie('login', $user, time() + (7 * 24 * 60 * 60), '/');
}
header('Location: panel.php');
exit();
} else {
$blad = 'Błędny login lub hasło!';
}
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<title>Logowanie</title>
</head>
<body>
<h2>Logowanie</h2>
<form method="POST">
    Login:<br>
    <input type="text" name="login"
    value="<?php echo htmlspecialchars($login); ?>" required>
    <br><br>
    Hasło:<br>
    <input type="password" name="haslo" required>
    <br><br>
    <input type="checkbox" name="zapamietaj">
    Zapamiętaj mnie
    <br><br>
    <button type="submit">Zaloguj się</button>
</form>
<p style="color:red;"><?php echo $blad; ?></p>
</body>
</html>
